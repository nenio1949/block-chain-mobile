<template>
  <router-view></router-view>
</template>
<script setup lang="ts">
  // import { ref, onMounted } from "vue";
  // import { useRouter } from "vue-router"; // 传递参数用 useRouter
  // // import { Loading } from "vant";
  // // import "./style.css";

  // const isLoading = ref<boolean>(true);

  // onMounted(() => {
  //   isLoading.value = false;
  //   const router = useRouter();
  //   console.log(router.currentRoute.value);

  //   router.push({
  //     path: "/"
  //   });
  // });
</script>
<!-- 
<style scoped>
  .logo {
    height: 6em;
    padding: 1.5em;
    will-change: filter;
  }
  .logo:hover {
    filter: drop-shadow(0 0 2em #646cffaa);
  }
  .logo.vue:hover {
    filter: drop-shadow(0 0 2em #42b883aa);
  }
</style> -->
