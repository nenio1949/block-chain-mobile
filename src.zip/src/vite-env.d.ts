/// <reference types="vite/client" />
interface ImportMetaEnv {
  /** 接口请求地址 */
  VITE_APP_SERVER_HOST: string;
}
